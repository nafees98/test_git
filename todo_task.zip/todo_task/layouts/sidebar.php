<div class="sidebar-nav">
          
  <div class="navbar navbar-default" role="navigation">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      </button>
      <span class="visible-xs navbar-brand">Menu</span>
    </div>
    <div class="navbar-collapse collapse sidebar-navbar-collapse">
     <h4>
          <i class="fa fa-paw"></i> <span>Admin Panel</span>
          </h4>
      <ul class="nav navbar-nav" id="sidenav01">
        <li><a href="dashboard.php"><i class="fa fa-desktop"></i> Dashboard</a></li>
        <li><a href="#" data-toggle="collapse" data-target="#catalog" data-parent="#sidenav01" class="collapsed"><i class="fa fa-book"></i> Catalog <i class="fa fa-angle-left pull-right"></i></a>
        <div class="collapse" id="catalog" style="height: 0px;">
            <ul class="nav nav-list">
              <li><a href="products.php"><i class="fa fa-dot-circle-o"></i> Products</a></li>
              <li><a href="categories.php"><i class="fa fa-dot-circle-o"></i> Categories</a></li>
            </ul>
          </div>
         </li>
        <li><a href="customers.php"><i class="fa fa-user"></i> Customers</a></li>
        <li><a href="artist.php"><i class="fa fa-paint-brush" aria-hidden="true"></i> Artist</a></li>
        <li><a href="vendors.php"><i class="glyphicon glyphicon-user"></i> Vendor</a></li>
      </ul>
      </div><!--/.nav-collapse -->
    </div>
  </div>