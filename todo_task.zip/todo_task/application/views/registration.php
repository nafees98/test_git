<link href="<?php echo base_url();?>css/custom.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/custom.css" rel="stylesheet">
<div class="container">
        <div class="card card-container">
            
            <p id="profile-name" class="profile-name-card">User Registration</p>
            <form class="form-signin" method="post" action="<?php echo site_url('index.php/Register/user_registration');?>">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="text" name="firstName" class="form-control" placeholder="First Name" required >
                <input type="text" name="lastName" class="form-control" placeholder="Last Name" required >
                <input type="text" name="email" class="form-control" placeholder="Email ID" required >
                <input type="text" name="phone" class="form-control" placeholder="Phone Number" required >
                <hr>
                <input type="text" name="UerId" class="form-control" placeholder="User Id" required autofocus>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
                <input class="btn btn-lg btn-primary btn-block btn-signin" type="submit" name='register' value="Sign Up" />
				 <a href="<?php echo site_url('index.php/Welcome/index');?>" class="forgot-password">
                Already have Account? Sign In
            </a>
            </form><!-- /form -->
        </div><!-- /card-container -->
    </div><!-- /container -->
