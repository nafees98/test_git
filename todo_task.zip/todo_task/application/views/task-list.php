
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col">
          <?php $this->load->view('layouts/sidebar');  ?>
        </div>
		
		<!-- top navigation -->
        <?php $this->load->view('layouts/top-nav');  ?>
        <!-- /top navigation -->
		<div class="right_col">
		<div class="col-md-12">
    <div class="content-header clearfix">
      <h1 class="pull-left">Task</h1>
    </div>
    <div class="panel panel-default">
    <div class="panel-body">
    <div class="table-responsive">
		<table id="artistlist" class="table table-striped table-responsive" cellpadding="3">
        <thead>
            <tr>
                <th>Sr. No.</th>
                <th>Task</th>
                <th>Task Description</th>
                <th>Priority</th>
                <th>Status</th>     
                <th>Action</th>                
            </tr>
        </thead>       
        <tbody>
        <?php $i=1; 
		foreach($all_Data as $val)
        {?>
        <tr>
			<td><?php echo $i;?></td>
			<td><?php echo $val->task_name; ?></td>
			<td><?php echo $val->task_description; ?></td>
			<td><?php echo $val->priority; ?></td>
			<td><?php echo ($val->status=='0')?'Pending':'Done'; ?></td>
			<td><?php if($val->status=='0'){ ?><a href='<?php echo site_url('index.php/Dashboard/manage_task/').$val->id;?>' title='Edit'><i class='glyphicon glyphicon-pencil' style='padding: 5px;'></i></a><?php }?></td>	
    	</tr>
          <?php $i++; } ?>        
 
        </tbody>
    </table>
    </div>
  </div>
  </div>

	</div>
	</div>
		</div>
	</div>

<?php $this->load->view('layouts/footer');  ?>
<script>

$(document).ready(function() {
  $('#artistlist').DataTable({
  "ordering":true
  });
});
</script>
  </body>
</html>
