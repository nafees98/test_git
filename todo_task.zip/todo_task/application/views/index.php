<link href="<?php echo base_url();?>css/custom.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/custom.css" rel="stylesheet">
<div class="container">
        <div class="card card-container">            
            <img id="profile-img" class="profile-img-card" src="<?php echo base_url();?>img/avatar_2x.png" />
            <p id="profile-name" class="profile-name-card"></p>
            <form class="form-signin" method="post" action="<?php echo site_url('index.php/welcome/login');?>">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="text" id="inputEmail" name="user_id" class="form-control" placeholder="User Id" required autofocus>
                <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
                <div id="remember" class="checkbox">
                    <label>
                        <input type="checkbox" value="remember-me"> Remember me
                    </label>
                </div>
                <input class="btn btn-lg btn-primary btn-block btn-signin" type="submit" name="login" value="Sign in"/>
            </form><!-- /form -->
            <a href="<?php echo site_url('index.php/Register/index');?>" class="forgot-password">
                Don't have Account? Sign Up
            </a>
        </div><!-- /card-container -->
    </div><!-- /container -->
