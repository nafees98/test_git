
	<div class="container body">
		<div class="main_container">
			<div class="col-md-3 left_col">
          <?php $this->load->view("layouts/sidebar.php"); ?>
        </div>
		
		<!-- top navigation -->
        <?php $this->load->view("layouts/top-nav.php"); ?>
        <!-- /top navigation -->
		<div class="right_col">
		<div class="col-md-12">
    <div class="content-header clearfix">
      <h1 class="pull-left">Task Details</h1>
      
    </div>
<div class="form-horizontal">
    <div class="nav-tab-wrapper">
    <ul class="nav nav-tabs">
                <li class="active"><a data-tab-name="product-info" data-toggle="tab" href="#product-info" aria-expanded="true">Task info</a></li>
            </ul>
      <div class="tab-content"> 
  
	  <form action="<?php echo site_url('index.php/Dashboard/update_task');?>" method="POST">
	  <?php foreach($data as $res){?>	
        	<div class="tab-pane active" id="product-info">
              <div class="row">
              <div class="col-sm-7">
              <div class="panel-group">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="col-sm-12">
                            <div class="form-group">
                              <div class="col-sm-4">
                                <div class="label-wrap">
                                <label class="control-label">Task name</label>
                                </div>
                              </div>
                              <div class="col-sm-8">
                                <input type="text" value="<?php echo $res->task_name;?>" name="" id="" readonly class="form-control" />
								<input type="hidden" value="<?php echo $res->id;?>" name="task_id" />
                              </div>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                              <div class="col-sm-4">
                                <div class="label-wrap">
                                <label class="control-label" >Task description</label>
                               </div>
                              </div>
                              <div class="col-sm-8">
                                <textarea name="" id="" class="form-control" readonly><?php echo $res->task_description;?></textarea>
                              </div>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                              <div class="col-sm-4">
                                <div class="label-wrap">
                                <label class="control-label">Task</label>
                               </div>
                              </div>
                              <div class="col-sm-8">
                                <textarea name="task_done" id="task_done" class="form-control"></textarea>
                              </div>
                            </div>
                        </div>
                        <div class="pull-right">
            <input type="submit" name="Save" value="Save" class="btn btn-primary"/>
      </div>
                    </div>
                      
                </div>
                
              </div>
              
        	</div>
            
    </div>
</div>
<?php } ?>
</form>
  

	</div>
	</div>
		</div>
	</div>

<?php $this->load->view("layouts/footer"); ?>
<script>

$(document).ready(function() {
  $('#productimage').DataTable({
  "ordering":true,
  "searching":false,
  "info":false,
  "paging":false
  });
  $("#Price").TouchSpin({
            min: -79228162514264337593543950335,
            max: 79228162514264337593543950335,
            decimals: 0, //always display 4 digits
            forcestepdivisibility: "none",
            verticalbuttons: true,
            postfix: "USD"
            });
	$("#weight").TouchSpin({
            min: -79228162514264337593543950335,
            max: 79228162514264337593543950335,
            decimals: 4, //always display 4 digits
            forcestepdivisibility: "none",
            verticalbuttons: true,
            postfix: "lb(s)"
            });
	$("#Length").TouchSpin({
            min: -79228162514264337593543950335,
            max: 79228162514264337593543950335,
            decimals: 4, //always display 4 digits
            forcestepdivisibility: "none",
            verticalbuttons: true,
            postfix: "inch(es)"
        });
	$("#Width").TouchSpin({
            min: -79228162514264337593543950335,
            max: 79228162514264337593543950335,
            decimals: 4, //always display 4 digits
            forcestepdivisibility: "none",
            verticalbuttons: true,
            postfix: "inch(es)"
        });
	$("#Height").TouchSpin({
            min: -79228162514264337593543950335,
            max: 79228162514264337593543950335,
            decimals: 4, //always display 4 digits
            forcestepdivisibility: "none",
            verticalbuttons: true,
            postfix: "inch(es)"
        });
	$("#Dorder").TouchSpin({
            min: -79228162514264337593543950335,
            max: 79228162514264337593543950335,
            decimals: 0, //always display 4 digits
            forcestepdivisibility: "none",
            verticalbuttons: true,
            postfix: ""
        });
});
</script>
  </body>
</html>
