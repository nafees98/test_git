
<div class="container body">
	<div class="main_container">
		<div class="col-md-3 left_col">
          <?php $this->load->view('layouts/sidebar');  ?>
        </div>
		<!-- top navigation -->
         <?php $this->load->view('layouts/top-nav');  ?>
        <!-- /top navigation -->
        <div class="right_col">
            <div class="col-md-12">
                <div class="content-header clearfix">
                    <h1>Dashboard</h1>                                        
                </div>
             <?php 
				foreach($allData as $val)					 
						$total_task=$val->total_task;
				foreach($doneData as $value)
						$total_task_done=$value->total_task_done;
												
					  
				 ?>
                <div class="row">
				
                   <div class="col-sm-8">
                   	<div class="panel panel-default">
                    	<div class="panel-heading"><i class="fa fa-line-chart" aria-hidden="true"></i> Analytics</div>
                        <div class="panel-body">
                        	<div id="analyticsdiv" style="width: 100%; height: 260px;"></div>
                        </div>
                    </div>
                   </div>
                   <div class="col-sm-4">
                   
                   </div>
                </div>
            </div>
        </div>
	</div>
</div>
 <?php $this->load->view('layouts/footer');  ?>
  
<script>
           
// Analutics Chart

var chart = AmCharts.makeChart("analyticsdiv", {
    "type": "xy",
    "theme": "none",
    "autoMarginOffset": 20,
    "dataProvider": [{
        "ax": 1,
        "ay": 0.5,
        "bx": 1,
        "by": 2.2
    }, {
        "ax": 2,
        "ay": 1.3,
        "bx": 2,
        "by": 4.9
    }, {
        "ax": 3,
        "ay": 2.3,
        "bx": 3,
        "by": 5.1
    }, {
        "ax": 4,
        "ay": 2.8,
        "bx": 4,
        "by": 5.3
    }, {
        "ax": 5,
        "ay": 3.5,
        "bx": 5,
        "by": 6.1
    }, {
        "ax": 6,
        "ay": 5.1,
        "bx": 6,
        "by": 8.3
    }, {
        "ax": 7,
        "ay": 6.7,
        "bx": 7,
        "by": 10.5
    }, {
        "ax": 8,
        "ay": 8,
        "bx": 8,
        "by": 12.3
    }, {
        "ax": 9,
        "ay": 8.9,
        "bx": 9,
        "by": 14.5
    }, {
        "ax": 10,
        "ay": 9.7,
        "bx": 10,
        "by": 15
    }, {
        "ax": 11,
        "ay": 10.4,
        "bx": 11,
        "by": 18.8
    }, {
        "ax": 12,
        "ay": 11.7,
        "bx": 12,
        "by": 19
    }],
    "valueAxes": [{
        "position": "bottom",
        "axisAlpha": 0,
        "dashLength": 1,
        "title": "Time (Hourly)"
    }, {
        "axisAlpha": 0,
        "dashLength": 1,
        "position": "left",
        "title": "Task"
    }],
    "startDuration": 1,
    "graphs": [{
        "balloonText": "x:[[x]] y:[[y]]",
        "bullet": "triangleUp",
        "lineAlpha": 0,
        "xField": "ax",
        "yField": "ay",
        "lineColor": "#FF6600",
        "fillAlphas": 0
    }, {
        "balloonText": "x:[[x]] y:[[y]]",
        "bullet": "triangleDown",
        "lineAlpha": 0,
        "xField": "bx",
        "yField": "by",
        "lineColor": "#FCD202",
        "fillAlphas": 0
    }],
    "trendLines": [{
        "finalValue": <?php echo $total_task_done;?>,
        "finalXValue": <?php echo $total_task;?>,
        "initialValue": 1,
        "initialXValue": 1,
        "lineColor": "#FF6600"
    }, {
        "finalValue": <?php echo $total_task;?>,
        "finalXValue": <?php echo $total_task;?>,
        "initialValue": 1,
        "initialXValue": 1,
        "lineColor": "#FCD202"
    }],
    "marginLeft": 64,
    "marginBottom": 60,
    "chartScrollbar": {},
    "chartCursor": {},
    "export": {
        "enabled": true,
        "position": "bottom-right"
    }
});
		
			
// $(document).ready(function() {
//   $('#keywordlist').DataTable({
//   "ordering":false,
//   "searching":false,
//   "info":false,
//   "paging":false
//   });
// });
        </script>

