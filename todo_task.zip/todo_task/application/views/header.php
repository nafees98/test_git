<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Panel</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>style.css" rel="stylesheet">
    <!-- <link href="<?php echo base_url();?>css/custom.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>css/custom.css" rel="stylesheet"> -->
    

  </head>
  <body>