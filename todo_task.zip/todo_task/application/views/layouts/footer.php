<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url();?>js/jquery-1.11.3.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.bootstrap-touchspin.js"></script>
<script src="<?php echo base_url();?>js/amcharts.js" type="text/javascript"></script>
<!-- <script src="<?php echo base_url();?>js/serial.js" type="text/javascript"></script> -->
<script src="<?php echo base_url();?>js/xy.js" type="text/javascript"></script>