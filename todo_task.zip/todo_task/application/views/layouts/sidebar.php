<div class="sidebar-nav">
          
  <div class="navbar navbar-default" role="navigation">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      </button>
      <span class="visible-xs navbar-brand">Menu</span>
    </div>
    <div class="navbar-collapse collapse sidebar-navbar-collapse">
     <h4>
          <i class="fa fa-paw"></i> <span>Admin Panel</span>
          </h4>
      <ul class="nav navbar-nav" id="sidenav01">
        <li><a href="<?php echo base_url('index.php/Dashboard/index');?>"><i class="fa fa-desktop"></i> Dashboard</a></li>       
        <li><a href="<?php echo base_url('index.php/Dashboard/task');?>"><i class="fa fa-paint-brush" aria-hidden="true"></i> Task</a></li>
   
      </ul>
      </div><!--/.nav-collapse -->
    </div>
  </div>