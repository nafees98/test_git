<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->database();
		$this->load->model('Register_Model');
		$this->load->library('session');
	}
	public function index()
	{
		$this->load->view('header');
		$this->load->view('registration');
		$this->load->view('footer');
	}

	public function user_registration()
	{		
		if($this->input->post('register'))
		{
			$data['user_id']=$this->input->post('UerId');
			$data['password']=md5($this->input->post('password'));
			$data['first_name']=$this->input->post('firstName');
			$data['last_name']=$this->input->post('lastName');
			$data['email']=$this->input->post('email');
			$data['phone']=$this->input->post('phone');
			$user_id=$this->Register_Model->register_user($data);
			$sessionData=array('first_name'=>$data['first_name'],'user_id'=>$user_id);
			$this->session->set_userdata($sessionData);
			redirect('index.php/Dashboard/index');

		}
		else
		{
			$this->session->set_userdata('errorMsg','Please enter valid data');
			redirect('index.php/Register/registration');
		}
	}
}
