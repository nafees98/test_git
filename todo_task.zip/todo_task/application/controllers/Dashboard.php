<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('html');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->database();
		$this->load->model('Dashboard_Model');
		$this->load->library('session');
		if($this->session->userdata('user_id')=='')
		{
			redirect('index.php/Welcome/index');
		}
	}
	public function task()
	{
		$result['all_Data']=$this->Dashboard_Model->get_user_task($this->session->userdata('user_id'));
		$this->load->view('header');
		$this->load->view('task-list',$result);
		$this->load->view('footer');
	}
	public function manage_task($task_id=null)
	{
		$result['data']=$this->Dashboard_Model->get_task($task_id);
		$this->load->view('header');
		$this->load->view('manage_task',$result);
		$this->load->view('footer');
	}
	public function update_task()
	{
		if($this->input->post('Save'))
		{
			$id=$this->input->post('task_id');
			$data['task']=$this->input->post('task_done');
			$data['status']='1';
			$result['allData']=$this->Dashboard_Model->update_task($id,$data);
			
		}
		redirect('index.php/Dashboard/task');
		
	}
	public function index()
	{
		$result['allData']=$this->Dashboard_Model->get_user_task_all($this->session->userdata('user_id'));
		$result['doneData']=$this->Dashboard_Model->get_user_task_done($this->session->userdata('user_id'));
		$this->load->view('header');
		$this->load->view('dashboard_view',$result);
		$this->load->view('footer');
	}
}
