<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_Model extends CI_Model {

	function login_user($user, $pass)
	{
		$sql="SELECT * FROM www_user WHERE user_id='".$user."' AND password='".$pass."'";
		$res = $this->db->query($sql);		
		if($res->num_rows()>0)
		{ 		
			return $res->result();
		}			
		else 
			return 0;
		
	}
}
?>