<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_Model extends CI_Model {

	function get_user_task($user)
	{
		$sql="select * from user_task WHERE www_user_id='".$user."'";
		$query = $this->db->query($sql);
		$data=$query->result();		
		return $data;
		
	}
	function get_user_task_all($user)
	{
		$sql="select count(*) as total_task from user_task WHERE www_user_id='".$user."'";
		$query = $this->db->query($sql);
		$data=$query->result();		
		return $data;
		
	}
	public function get_user_task_done($user)
	{
		$sql="select count(*) as total_task_done from user_task WHERE www_user_id='".$user."' AND status='1'";
		$query = $this->db->query($sql);
		$data=$query->result();
		return $data;
	}
	function get_task($task_id)
	{
		echo $sql="select * from user_task WHERE id='".$task_id."'";
		$query = $this->db->query($sql);
		return $query->result();
		
	}
	function update_task($id,$data)
	{
		$this->db->where('id', $id);
		$this->db->update('user_task', $data);
		
	}
}
?>