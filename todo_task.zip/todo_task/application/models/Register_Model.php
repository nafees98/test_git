<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_Model extends CI_Model {

	function register_user($data)
	{
		$sqlQry=$this->db->insert('www_user',$data);
		if($sqlQry==true)
			return $this->db->insert_id();
		else
			return false;
	}
}
?>