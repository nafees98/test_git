-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2019 at 09:14 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_todotask`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_task`
--

CREATE TABLE `user_task` (
  `id` int(10) NOT NULL,
  `task_name` varchar(200) NOT NULL,
  `task_description` text NOT NULL,
  `task` text NOT NULL,
  `www_user_id` int(10) NOT NULL,
  `priority` enum('High','Low','Medium') NOT NULL,
  `status` enum('0','1') NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_task`
--

INSERT INTO `user_task` (`id`, `task_name`, `task_description`, `task`, `www_user_id`, `priority`, `status`, `created_date`, `modified_date`) VALUES
(1, 'Task1', 'Create A user Interface for admin Panel', 'asdasdadas', 1, 'High', '0', '2019-07-16 17:57:03', '0000-00-00 00:00:00'),
(2, 'Task2', 'Create A user Interface for admin Panel1', 'adadfada', 1, 'Low', '1', '2019-07-16 16:32:20', '0000-00-00 00:00:00'),
(3, 'Task3', 'Create A user Interface for admin Panel3', '', 1, 'High', '0', '2019-07-16 18:36:04', '0000-00-00 00:00:00'),
(4, 'Task 4', 'Create A user Interface for admin Panel4', '', 1, 'High', '1', '2019-07-16 18:36:04', '0000-00-00 00:00:00'),
(5, 'Task5', 'Task 5- sampale', 'adsfsad', 1, 'Low', '1', '2019-07-16 19:10:49', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `www_user`
--

CREATE TABLE `www_user` (
  `id` int(10) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(15) NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `www_user`
--

INSERT INTO `www_user` (`id`, `user_id`, `password`, `first_name`, `last_name`, `email`, `phone`, `status`) VALUES
(1, 'md_nafees', '912ec803b2ce49e4a541068d495ab570', 'Nafees', 'ansari', 'ansari.nafees96@gmail.com', 2147483647, '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_task`
--
ALTER TABLE `user_task`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `www_user`
--
ALTER TABLE `www_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_task`
--
ALTER TABLE `user_task`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `www_user`
--
ALTER TABLE `www_user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
